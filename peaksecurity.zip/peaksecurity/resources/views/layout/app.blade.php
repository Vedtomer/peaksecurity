<!DOCTYPE html>
<html data-wf-domain="security-wcopilot.webflow.io" data-wf-page="64735306bb4de7eb23c0f6cd"
    data-wf-site="64735306bb4de7eb23c0f5ee" lang="en">

@include('layout.head')

<body>
   @include('layout.header')
   @yield('content')
    @include('layout.footer')
    @include('layout.script')
</body>

</html>
