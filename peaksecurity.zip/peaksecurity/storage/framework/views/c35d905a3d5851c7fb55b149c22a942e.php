 <div class="footer">
        <div class="base-container w-container">
            <div class="footer-wrapper">
                <div class="footer-brand-wrapper">
                    <h2 class="medium-title left-text">Sing Up to Newsletter</h2>
                    <div class="from w-form">
                        <form id="email-form" name="email-form" data-name="Email Form" method="get"
                            class="footer-form" data-wf-page-id="64735306bb4de7eb23c0f6cd"
                            data-wf-element-id="f02b15c7-4fe4-e4fd-b496-26822c64ee27"><input
                                class="footer-input w-input" maxlength="256" name="email" data-name="Email"
                                placeholder="Email" type="email" id="email" required="" /><input
                                type="submit" data-wait="Please wait..."
                                class="primary-button footer-button w-button" value="Subscribe" /></form>
                        <div class="success-message w-form-done">
                            <div>Thank you! Your submission has been received!</div>
                        </div>
                        <div class="error-message w-form-fail">
                            <div>Oops! Something went wrong while submitting the form.</div>
                        </div>
                    </div>
                </div>
                <div class="footer-link-wrap">
                    <div class="footer-links-wrapper"><a href="/" aria-current="page"
                            class="footer-link w--current">Home</a><a href="/about-us"
                            class="footer-link">About</a></div>
                    <div class="footer-links-wrapper div-block-7 div-block-8"><a href="/our-team"
                            class="footer-link">Our Team</a><a href="/services" class="footer-link">Services</a>
                    </div>
                    <div class="footer-links-wrapper"><a href="/projects" class="footer-link">Projects</a><a
                            href="/blog" class="footer-link">Blog</a></div>
                </div>
            </div>
            <div class="copyright-wrapper">
                <div class="footer-bottom-wrapper">
                    <div class="footer-copyright">© Security. All Rights Reserved 2024. <a
                            href="/templates/licensing" class="footer-copyright">Licensing</a></div>
                    <div class="footer-rights-wrapper">
                        <div class="footer-rights"><a href="https://wcopilot.com/templates" target="_blank"
                                class="footer-copyright-link">Template</a> by <a href="https://wcopilot.com/"
                                target="_blank" class="footer-copyright-link">wCopilot</a></div>
                        <div class="footer-rights">Powered by <a href="https://webflow.com/" target="_blank"
                                class="footer-copyright-link">Webflow</a></div>
                    </div>
                </div>
                <div class="footer-social-icons-wrapper"><a href="https://www.facebook.com/" target="_blank"
                        class="footer-social-icon"></a><a href="https://twitter.com/" target="_blank"
                        class="footer-social-icon"></a><a href="https://www.linkedin.com/" target="_blank"
                        class="footer-social-icon"></a></div>
            </div>
        </div>
    </div>
    

    
<?php /**PATH /var/www/html/personal/peaksecurity/resources/views/layout/footer.blade.php ENDPATH**/ ?>