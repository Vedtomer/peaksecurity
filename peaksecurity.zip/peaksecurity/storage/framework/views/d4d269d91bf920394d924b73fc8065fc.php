<!DOCTYPE html>
<html data-wf-domain="security-wcopilot.webflow.io" data-wf-page="64735306bb4de7eb23c0f6cd"
    data-wf-site="64735306bb4de7eb23c0f5ee" lang="en">

<?php echo $__env->make('layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
   <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layout.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH /var/www/html/personal/peaksecurity/resources/views/layout/app.blade.php ENDPATH**/ ?>