 <div data-animation="over-left" data-collapse="medium" data-duration="400" data-easing="ease" data-easing2="ease"
     data-doc-height="1" role="banner" class="navbar w-nav">
     <div class="navbar-background"></div>
     <div class="nav-container w-container">
         <div class="nav-menu-wrapper"><a href="/" aria-current="page" class="brand w-nav-brand w--current">
                 <img src="https://assets-global.website-files.com/64735306bb4de7eb23c0f5ee/6475bb5d6c0bc62575b7ff9c_logo.svg"
                     loading="lazy" alt="" height="30" class="logo-image" /></a>
             <nav role="navigation" class="nav-menu w-nav-menu">
                 <div class="tablet-menu"><a href="/" aria-current="page"
                         class="brand-tablet w-nav-brand w--current"><img
                             src="https://assets-global.website-files.com/64735306bb4de7eb23c0f5ee/6475bb5d6c0bc62575b7ff9c_logo.svg"
                             loading="lazy" alt="" height="30" class="logo-image" /></a>
                     <div class="close-menu-button w-nav-button"><img
                             src="https://assets-global.website-files.com/64735306bb4de7eb23c0f5ee/64735306bb4de7eb23c0f745_close-btn.svg"
                             loading="lazy" alt="icon" class="nav-close-icon" /></div>
                 </div>
                 <div class="menu-wrap">
                     <div data-hover="true" data-delay="0" data-w-id="835e7a36-0bd9-c0ee-0eee-ba31bc15d130"
                         class="nav-dropdown w-dropdown">
                         <div class="nav-dropdown-toggle w-dropdown-toggle">
                             <div class="nav-dropdown-icon w-icon-dropdown-toggle"></div>
                             <p class="nav-item-title">Demos</p>
                         </div>
                         <nav class="nav-dropdown-list w-dropdown-list">
                             <div class="nav-dropdown-link-wrapper"><a href="/" aria-current="page"
                                     class="nav-dropdown-link w-dropdown-link w--current"><span
                                         class="nav-dropdown-link-line"> </span>Home 1</a><a href="/home-2"
                                     class="nav-dropdown-link w-dropdown-link"><span class="nav-dropdown-link-line">
                                     </span>Home 2</a><a href="/home-3" class="nav-dropdown-link w-dropdown-link"><span
                                         class="nav-dropdown-link-line">
                                     </span>Home 3</a></div>
                         </nav>
                     </div>
                     <div data-hover="true" data-delay="0" data-w-id="835e7a36-0bd9-c0ee-0eee-ba31bc15d1a0"
                         class="nav-dropdown w-dropdown">
                         <div class="nav-dropdown-toggle w-dropdown-toggle">
                             <div class="nav-dropdown-icon w-icon-dropdown-toggle"></div>
                             <p class="nav-item-title">who we are</p>
                         </div>
                         <nav class="nav-dropdown-list w-dropdown-list">
                             <div class="nav-dropdown-link-wrapper"><a href="/about-us"
                                     class="nav-dropdown-link w-dropdown-link"><span class="nav-dropdown-link-line">
                                     </span>About Us</a><a href="/pricing"
                                     class="nav-dropdown-link w-dropdown-link"><span class="nav-dropdown-link-line">
                                     </span>Pricing</a><a href="/our-team"
                                     class="nav-dropdown-link w-dropdown-link"><span class="nav-dropdown-link-line">
                                     </span>Our Team</a><a href="/testimonials"
                                     class="nav-dropdown-link w-dropdown-link"><span class="nav-dropdown-link-line">
                                     </span>Testimonials</a><a href="/faq"
                                     class="nav-dropdown-link w-dropdown-link"><span class="nav-dropdown-link-line">
                                     </span>FAQ</a><a href="/contact-us" class="nav-dropdown-link w-dropdown-link"><span
                                         class="nav-dropdown-link-line">
                                     </span>Contact Us</a></div>
                         </nav>
                     </div>
                     <div data-hover="true" data-delay="0" data-w-id="835e7a36-0bd9-c0ee-0eee-ba31bc15d1c3"
                         class="nav-dropdown w-dropdown">
                         <div class="nav-dropdown-toggle w-dropdown-toggle">
                             <div class="nav-dropdown-icon w-icon-dropdown-toggle"></div>
                             <p class="nav-item-title">Services</p>
                         </div>
                         <nav class="nav-dropdown-list w-dropdown-list">
                             <div class="nav-dropdown-link-wrapper"><a href="/services"
                                     class="nav-dropdown-link w-dropdown-link"><span class="nav-dropdown-link-line">
                                     </span>Services</a><a
                                     href="https://security-wcopilot.webflow.io/services/security-consultancy-services"
                                     class="nav-dropdown-link w-dropdown-link"><span class="nav-dropdown-link-line">
                                     </span>Service Details</a></div>
                         </nav>
                     </div>
                     <div data-hover="true" data-delay="0" data-w-id="835e7a36-0bd9-c0ee-0eee-ba31bc15d1d2"
                         class="nav-dropdown w-dropdown">
                         <div class="nav-dropdown-toggle w-dropdown-toggle">
                             <div class="nav-dropdown-icon w-icon-dropdown-toggle"></div>
                             <p class="nav-item-title">Projects</p>
                         </div>
                         <nav class="nav-dropdown-list w-dropdown-list">
                             <div class="nav-dropdown-link-wrapper"><a href="/projects"
                                     class="nav-dropdown-link w-dropdown-link"><span class="nav-dropdown-link-line">
                                     </span>Projects</a><a
                                     href="https://security-wcopilot.webflow.io/projects/customized-security-solution-for-a-smart-home"
                                     class="nav-dropdown-link w-dropdown-link"><span class="nav-dropdown-link-line">
                                     </span>Projects details</a></div>
                         </nav>
                     </div>
                     
                     <div data-hover="true" data-delay="0" data-w-id="835e7a36-0bd9-c0ee-0eee-ba31bc15d1f8"
                         class="nav-dropdown w-dropdown">
                         <div class="nav-dropdown-toggle w-dropdown-toggle">
                             <div class="nav-dropdown-icon w-icon-dropdown-toggle"></div>
                             <p class="nav-item-title">All Pages</p>
                         </div>
                         <nav class="nav-dropdown-list megamenu w-dropdown-list">
                             <div class="dropdown-wrapper">
                                 <div class="nav-dropdown-link-wrapper size"><a href="/" aria-current="page"
                                         class="nav-dropdown-link w-dropdown-link w--current"><span
                                             class="nav-dropdown-link-line"> </span>Home 1</a><a href="/home-2"
                                         class="nav-dropdown-link w-dropdown-link"><span
                                             class="nav-dropdown-link-line"> </span>Home 2</a><a href="/home-3"
                                         class="nav-dropdown-link w-dropdown-link"><span
                                             class="nav-dropdown-link-line"> </span>Home 3</a><a href="/about-us"
                                         class="nav-dropdown-link w-dropdown-link"><span
                                             class="nav-dropdown-link-line"> </span>About Us</a><a href="/services"
                                         class="nav-dropdown-link w-dropdown-link"><span
                                             class="nav-dropdown-link-line"> </span>Services</a><a
                                         href="https://security-wcopilot.webflow.io/services/security-consultancy-services"
                                         class="nav-dropdown-link w-dropdown-link"><span
                                             class="nav-dropdown-link-line"> </span>Service Details</a><a
                                         href="/pricing" class="nav-dropdown-link w-dropdown-link"><span
                                             class="nav-dropdown-link-line"> </span>Pricing</a><a href="/projects"
                                         class="nav-dropdown-link w-dropdown-link"><span
                                             class="nav-dropdown-link-line"> </span>Projects</a><a
                                         href="https://security-wcopilot.webflow.io/projects/customized-security-solution-for-a-smart-home"
                                         class="nav-dropdown-link w-dropdown-link"><span
                                             class="nav-dropdown-link-line"> </span>Project Details</a></div>
                                 <div class="nav-dropdown-link-wrapper size"><a href="/our-team"
                                         class="nav-dropdown-link w-dropdown-link"><span
                                             class="nav-dropdown-link-line"> </span>Team</a><a href="/faq"
                                         class="nav-dropdown-link w-dropdown-link"><span
                                             class="nav-dropdown-link-line"> </span>FAQ</a><a href="/testimonials"
                                         class="nav-dropdown-link w-dropdown-link"><span
                                             class="nav-dropdown-link-line"> </span>Testimonials</a><a
                                         href="/contact-us" class="nav-dropdown-link w-dropdown-link"><span
                                             class="nav-dropdown-link-line"> </span>Contact Us</a><a href="/blog"
                                         class="nav-dropdown-link w-dropdown-link"><span
                                             class="nav-dropdown-link-line"> </span>Blog</a><a
                                         href="https://security-wcopilot.webflow.io/blog-posts/choosing-the-right-security-camera-for-your-specific-needs"
                                         class="nav-dropdown-link w-dropdown-link"><span
                                             class="nav-dropdown-link-line"> </span>Blog details</a><a href="/shop"
                                         class="nav-dropdown-link w-dropdown-link"><span
                                             class="nav-dropdown-link-line"> </span>Shop </a><a
                                         href="https://security-wcopilot.webflow.io/product/taurus-r"
                                         class="nav-dropdown-link w-dropdown-link"><span
                                             class="nav-dropdown-link-line"> </span>Shop Details</a><a
                                         href="/templates/style-guide" class="nav-dropdown-link w-dropdown-link"><span
                                             class="nav-dropdown-link-line"> </span>Style Guide</a></div>
                             </div>
                         </nav>
                     </div><a href="#" class="primary-button header">contact us</a>
                 </div>
             </nav>
             <div class="right-navbar-wrap">
                 <div class="links-wrap">
                     <p class="navbar-phone-icon"></p><a href="tel:(704)555-0127" class="navbar-link">(704)
                         555-0127</a>
                 </div>
                 
                 <a href="/contact-us" class="primary-button-white tablet-button">contact us</a>
             </div>
             <div class="menu-button w-nav-button"><img
                     src="https://assets-global.website-files.com/64735306bb4de7eb23c0f5ee/6475de1963db6e5b5f56e6f4_icon%20(4).png"
                     loading="lazy" alt="" height="16" class="image-burger" /></div>
         </div>
     </div>
 </div>
<?php /**PATH /var/www/html/personal/peaksecurity/resources/views/layout/header.blade.php ENDPATH**/ ?>